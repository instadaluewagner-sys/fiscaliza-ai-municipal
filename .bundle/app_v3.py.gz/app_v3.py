
import io,os,re
from typing import List
from fastapi import FastAPI,UploadFile,File,Form
from fastapi.responses import HTMLResponse,JSONResponse,StreamingResponse
import fitz,pytesseract
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4

app=FastAPI(title="Fiscaliza.AI Municipal",version="3.1")
STATE={}

def n(s):
    t=str.maketrans("áàâãäéèêëíìîïóòôõöúùûüç","aaaaaeeeeiiiiooooouuuuc")
    return re.sub(r"\s+"," ",(s or "").lower().translate(t)).strip()

def c(s): return re.sub(r"\s+"," ",s or "").strip()

def pages(data,name):
    d=fitz.open(stream=data,filetype="pdf"); out=[]
    for i,p in enumerate(d):
        txt=c(p.get_text())
        if len(txt)<80:
            try:
                px=p.get_pixmap(matrix=fitz.Matrix(1.6,1.6),alpha=False)
                im=Image.frombytes("RGB",[px.width,px.height],px.samples)
                txt=c(pytesseract.image_to_string(im,lang=os.getenv("OCR_LANG","por+eng")))
            except: pass
        out.append({"file":name,"page":i+1,"text":txt})
    return out

RULES={
"contrato":["contrato administrativo","contrato nº","contrato n.","instrumento contratual"],
"notificacao":["notificacao extrajudicial","notificacao administrativa","fica notificada"],
"intimacao":["intimacao","fica intimada","prazo para defesa"],
"defesa":["defesa administrativa","razoes de defesa","apresenta sua defesa","em sua defesa"],
"parecer_juridico":["parecer juridico","procuradoria juridica","assessoria juridica"],
"parecer_tecnico":["parecer tecnico","relatorio tecnico","manifestacao tecnica"],
"decisao":["decisao administrativa"," decido ","determino a instauracao","autorizo a abertura","rescisao unilateral","extincao unilateral"],
"termo_recebimento":["termo de recebimento","recebimento definitivo","recebimento provisorio"],
"nota_fiscal":["nota fiscal","danfe","nf-e"],
"empenho":["nota de empenho","empenho nº","empenho n."],
"ordem_fornecimento":["ordem de fornecimento","autorizacao de fornecimento"]
}
LABEL={
"contrato":"Contrato","notificacao":"Notificação","intimacao":"Intimação","defesa":"Defesa administrativa",
"parecer_juridico":"Parecer jurídico","parecer_tecnico":"Parecer técnico","decisao":"Decisão",
"termo_recebimento":"Termo de recebimento","nota_fiscal":"Nota fiscal","empenho":"Empenho","ordem_fornecimento":"Ordem de fornecimento"
}

def classify(ps):
    found=[]
    for p in ps:
        head=n(p["text"])[:2200]
        for typ,pats in RULES.items():
            if any(x in head for x in pats):
                found.append({**p,"type":typ})
    return found

def group(found):
    out=[]
    for typ in LABEL:
        xs=[x for x in found if x["type"]==typ]
        if not xs: continue
        by={}
        for x in xs: by.setdefault(x["file"],[]).append(x["page"])
        for f,pg in by.items():
            out.append({"type":typ,"label":LABEL[typ],"file":f,"pages":sorted(set(pg))})
    return out

def snippets(ps,terms,limit=4):
    out=[]
    for p in ps:
        for s in re.split(r"(?<=[.!?;])\s+",p["text"]):
            z=n(s)
            if len(s)>25 and any(re.search(t,z) for t in terms):
                out.append({"file":p["file"],"page":p["page"],"text":c(s)[:380]})
                if len(out)>=limit:return out
    return out

def quantity(ps):
    cand=[]
    for p in ps:
        for s in re.split(r"(?<=[.!?;])\s+",p["text"]):
            z=n(s)
            if any(x in z for x in ["por viagem","metade da quantidade","simulacao","estimativa de frete"]): continue
            if any(x in z for x in ["quantidade total","quantidade contratada","quantidade prevista"]):
                nums=re.findall(r"\b\d{1,6}\b",s.replace(".",""))
                if nums:cand.append((nums[-1],p,s))
    vals={x[0] for x in cand}
    if len(vals)==1:
        v,p,s=cand[0]
        return {"value":v,"source":{"file":p["file"],"page":p["page"],"text":c(s)[:260]}}
    return {"value":"Não identificado com segurança","source":None}

def analyze(ps):
    f=classify(ps); pcs=group(f); has={k:any(x["type"]==k for x in pcs) for k in LABEL}
    nd=snippets(ps,[r"nenhuma entrega",r"nao houve entrega",r"nao realizou (?:a )?entrega",r"inexecucao total"],5)
    defense=snippets(ps,[r"reequilibr",r"aumento.*custo",r"frete",r"impossibil",r"forca maior",r"inviabil"],5)
    contra=snippets(ps,[r"nenhuma entrega",r"nao houve entrega",r"descumpr",r"inexecucao",r"rescisao unilateral",r"extincao unilateral"],6)
    sanc=snippets(ps,[r"abertura.*processo administrativo sancionador",r"instauracao.*processo administrativo sancionador"],3)
    delivered=snippets(ps,[r"foi entregue",r"entrega realizada",r"recebido.*objeto"],2)
    pend=[]
    if delivered and not has["termo_recebimento"]:
        pend.append("Há indício de entrega, mas não foi localizado termo de recebimento.")
    if not has["defesa"]:
        pend.append("Não foi localizada defesa administrativa com segurança.")
    if not(has["notificacao"] or has["intimacao"]):
        pend.append("Não foi localizada notificação/intimação prévia com segurança.")
    if sanc:
        pend.append("Os autos indicam abertura/instauração de processo sancionador posterior; não presuma sanção final a partir deste PDF.")
    if sanc:
        concl="Os autos registram abertura/instauração de processo administrativo sancionador posterior. Isso não equivale a sanção já aplicada."
    elif has["decisao"] and has["defesa"] and (has["notificacao"] or has["intimacao"]):
        concl="Foram localizadas peças relevantes de contraditório e decisão. A ferramenta organiza a evidência; a decisão permanece humana."
    else:
        concl="Nem todas as peças esperadas foram identificadas com segurança. Revise a classificação por páginas antes de concluir."
    return {"pieces":pcs,"has":has,"defense":defense,"contra":contra,"pending":pend,"quantity":quantity(ps),"conclusion":concl,"no_delivery":nd}

def ask(q,a,ps):
    z=n(q)
    if "defesa" in z:
        return {"answer":"Sim. Foi localizada defesa administrativa." if a["has"]["defesa"] else "Não localizei defesa administrativa com segurança.","sources":[]}
    if "notifica" in z or "intim" in z:
        return {"answer":"Sim. Foi localizada comunicação prévia." if (a["has"]["notificacao"] or a["has"]["intimacao"]) else "Não localizei notificação/intimação com segurança.","sources":[]}
    if "quantidade" in z:
        return {"answer":"Quantidade: "+a["quantity"]["value"],"sources":[]}
    if "entrega" in z and a["no_delivery"]:
        s=a["no_delivery"][0]
        return {"answer":"Há registro textual indicando ausência de entrega.","sources":[f'{s["file"]} · p.{s["page"]}']}
    if "decis" in z or "rescis" in z:
        return {"answer":a["conclusion"],"sources":[]}
    words=[w for w in re.findall(r"[a-z0-9çãõáéíóúâêô]{4,}",q.lower()) if w not in {"qual","quais","como","para","sobre","processo"}]
    sc=[]
    for p in ps:
        for s in re.split(r"(?<=[.!?;])\s+",p["text"]):
            k=sum(1 for w in words if n(w) in n(s))
            if k:sc.append((k,p,s))
    sc.sort(key=lambda x:(-x[0],x[1]["page"]))
    return {"answer":"Encontrei trechos relacionados; revise as fontes antes de concluir." if sc else "Não encontrei evidência textual suficiente.","sources":[f'{p["file"]} · p.{p["page"]} — {c(s)[:250]}' for _,p,s in sc[:3]]}

HTML = r'''<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fiscaliza.AI</title><style>
body{margin:0;font-family:Arial;background:#f4f7fb;color:#102235}.w{display:grid;grid-template-columns:240px 1fr;min-height:100vh}.s{background:#073b4b;color:#fff;padding:24px}.m{padding:28px}.card{background:#fff;border:1px solid #dce5ed;border-radius:14px;padding:18px;margin:16px 0}.up{border:2px dashed #8fb0d8;text-align:center}.btn{background:#285ee8;color:#fff;border:0;border-radius:9px;padding:11px 16px;font-weight:bold}.piece{border-left:4px solid #16945f;background:#f8fbfd;padding:9px;margin:7px 0}.warn{border-left-color:#c78300}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.row{display:flex;gap:10px;flex-wrap:wrap}.k{border:1px solid #dde6ee;border-radius:10px;padding:12px;min-width:190px}.muted{color:#607486}.hidden{display:none}@media(max-width:800px){.w{grid-template-columns:1fr}.grid{grid-template-columns:1fr}}</style></head><body><div class="w"><aside class="s"><h2>Fiscaliza.AI Municipal</h2><small>Copiloto auditável para pequenos municípios</small><p>Analisar processo</p><p>Pergunte ao processo</p><p>Rastreabilidade</p><p>Relatório PDF</p></aside><main class="m"><b style="color:#285ee8">VERSÃO 3.1 · LEITURA POR PEÇAS</b><h1>Entenda um processo administrativo com cada resposta ligada à prova.</h1><p class="muted">Um único PDF pode conter contrato, notificação, defesa, parecer e decisão. A análise agora é feita por página.</p><div class="card up"><h3>Envie PDFs do processo</h3><input id="f" type="file" accept=".pdf" multiple><br><br><button class="btn" onclick="run()">Analisar documentos</button><p id="st" class="muted"></p></div><div id="r" class="hidden"><div class="card"><h2>Análise assistida</h2><p id="con"></p><div id="kpi" class="row"></div></div><div class="card"><h2>Peças processuais identificadas</h2><div id="pcs"></div></div><div class="grid"><div class="card"><h2>Elementos favoráveis à defesa</h2><div id="def"></div></div><div class="card"><h2>Pontos a confrontar</h2><div id="ctr"></div></div></div><div class="card"><h2>Pendências e limites</h2><div id="pen"></div></div><div class="card"><h2>Pergunte ao processo</h2><input id="q" style="width:70%;padding:10px"><button class="btn" onclick="qa()">Perguntar</button><div id="ans"></div></div><div class="card"><button class="btn" onclick="window.open('/api/report')">Baixar relatório PDF</button></div></div></main></div><script>
const E=s=>(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const S=a=>a&&a.length?a.map(x=>`<div class="piece">${E(x.text)}<br><small>${E(x.file)} · p.${x.page}</small></div>`).join(''):'<p class="muted">Nenhum trecho específico extraído.</p>';
async function run(){let fs=f.files;if(!fs.length)return alert('Selecione PDF');let fd=new FormData();for(let x of fs)fd.append('files',x);st.innerText='Lendo páginas e classificando peças...';let z=await fetch('/api/analyze',{method:'POST',body:fd}),d=await z.json();if(!z.ok){st.innerText=d.detail||'Erro';return}st.innerText=d.pages+' páginas analisadas';r.classList.remove('hidden');let a=d.analysis;con.innerText=a.conclusion;kpi.innerHTML=`<div class=k><b>Defesa</b><br>${a.has.defesa?'Localizada':'Não localizada'}</div><div class=k><b>Notificação/intimação</b><br>${a.has.notificacao||a.has.intimacao?'Localizada':'Não localizada'}</div><div class=k><b>Decisão</b><br>${a.has.decisao?'Localizada':'Não localizada'}</div><div class=k><b>Quantidade total</b><br>${E(a.quantity.value)}</div>`;pcs.innerHTML=a.pieces.map(x=>`<div class=piece><b>${E(x.label)}</b><br><small>${E(x.file)} · p. ${x.pages.join(', ')}</small></div>`).join('');def.innerHTML=S(a.defense);ctr.innerHTML=S(a.contra);pen.innerHTML=a.pending.length?a.pending.map(x=>`<div class="piece warn">${E(x)}</div>`).join(''):'<p>Nenhuma pendência automática registrada.</p>';r.scrollIntoView({behavior:'smooth'})}
async function qa(){let fd=new FormData();fd.append('question',q.value);let z=await fetch('/api/ask',{method:'POST',body:fd}),d=await z.json();ans.innerHTML=`<p><b>${E(d.answer)}</b></p>`+(d.sources||[]).map(x=>`<div class=piece>${E(x)}</div>`).join('')}
</script></body></html>'''

@app.get("/",response_class=HTMLResponse)
def home(): return HTML

@app.get("/api/health")
def health(): return {"status":"ok","version":"3.1","engine":"page-piece"}

@app.post("/api/analyze")
async def api_analyze(files:List[UploadFile]=File(...)):
    ps=[]
    for f in files:
        if f.filename.lower().endswith(".pdf"):ps+=pages(await f.read(),f.filename)
    if not ps:return JSONResponse({"detail":"Nenhum PDF legível."},400)
    a=analyze(ps);STATE.clear();STATE.update({"a":a,"ps":ps})
    return {"pages":len(ps),"analysis":a}

@app.post("/api/ask")
async def api_ask(question:str=Form(...)):
    if not STATE:return {"answer":"Analise um processo primeiro.","sources":[]}
    return ask(question,STATE["a"],STATE["ps"])

@app.get("/api/report")
def report():
    if not STATE:return JSONResponse({"detail":"Analise um processo primeiro."},400)
    b=io.BytesIO();cv=canvas.Canvas(b,pagesize=A4);y=800;cv.setFont("Helvetica-Bold",14);cv.drawString(50,y,"Fiscaliza.AI Municipal - Relatório");y-=28;cv.setFont("Helvetica",9)
    lines=[STATE["a"]["conclusion"],"","Peças identificadas:"]+[f'- {x["label"]}: {x["file"]}, p. {", ".join(map(str,x["pages"]))}' for x in STATE["a"]["pieces"]]+["","Pendências:"]+["- "+x for x in STATE["a"]["pending"]]
    for line in lines:
        while len(line)>100:
            cut=line.rfind(" ",0,100);cut=cut if cut>0 else 100;part=line[:cut];line=line[cut:].lstrip();cv.drawString(50,y,part);y-=13
        cv.drawString(50,y,line);y-=13
        if y<50:cv.showPage();y=800;cv.setFont("Helvetica",9)
    cv.save();b.seek(0);return StreamingResponse(b,media_type="application/pdf",headers={"Content-Disposition":"attachment; filename=fiscaliza_relatorio.pdf"})
