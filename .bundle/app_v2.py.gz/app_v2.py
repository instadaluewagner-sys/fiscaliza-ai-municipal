from __future__ import annotations

import io
import os
import re
import subprocess
import tempfile
import unicodedata
import uuid
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import List, Dict, Any

import fitz  # PyMuPDF
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors

app = FastAPI(title="Fiscaliza.AI Municipal", version="2.0")

PROCESSES: Dict[str, Dict[str, Any]] = {}


def norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode("ascii")
    return re.sub(r"\s+", " ", s).strip().lower()


@dataclass
class PageInfo:
    file: str
    page: int
    text: str
    kind: str
    ocr: bool = False


CLASSIFIERS = [
    ("defesa", ["defesa administrativa", "razoes de defesa", "apresenta defesa", "manifestacao da contratada", "manifestacao da empresa"]),
    ("notificação", ["notificacao extrajudicial", "notificacao", "notifique-se", "fica notificada", "notificar a empresa"]),
    ("intimação", ["intimacao", "fica intimada", "intime-se", "prazo para defesa"]),
    ("parecer jurídico", ["parecer juridico", "procuradoria", "assessoria juridica", "fundamentacao juridica"]),
    ("parecer técnico", ["parecer tecnico", "relatorio tecnico", "manifestacao tecnica", "fiscal do contrato"]),
    ("decisão", ["decisao administrativa", "decido", "determino", "resolvo", "extincao unilateral", "rescisao unilateral"]),
    ("termo de recebimento", ["termo de recebimento", "recebimento definitivo", "recebimento provisorio"]),
    ("nota fiscal", ["nota fiscal", "nf-e", "danfe"]),
    ("ordem de fornecimento", ["ordem de fornecimento", "autorizacao de fornecimento", "ordem de compra"]),
    ("empenho", ["nota de empenho", "empenho n", "empenho nº"]),
    ("contrato", ["contrato administrativo", "contrato n", "contrato nº", "instrumento contratual", "clausula primeira"]),
    ("norma", ["lei 14.133", "lei nº 14.133", "decreto", "regulamento", "art."]),
]


def classify_page(text: str) -> str:
    t = norm(text[:12000])
    scores = []
    for kind, terms in CLASSIFIERS:
        score = sum(2 if term in t[:2500] else 1 for term in terms if term in t)
        if score:
            scores.append((score, kind))
    if not scores:
        return "outro"
    scores.sort(reverse=True)
    return scores[0][1]


def ocr_page(page: fitz.Page) -> str:
    try:
        pix = page.get_pixmap(matrix=fitz.Matrix(1.7, 1.7), alpha=False)
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as img:
            img.write(pix.tobytes("png"))
            img_path = img.name
        out = subprocess.run(
            ["tesseract", img_path, "stdout", "-l", os.getenv("OCR_LANG", "por+eng"), "--psm", "6"],
            capture_output=True, text=True, timeout=35
        )
        try:
            os.unlink(img_path)
        except OSError:
            pass
        return out.stdout or ""
    except Exception:
        return ""


def extract_pages(name: str, data: bytes) -> List[PageInfo]:
    doc = fitz.open(stream=data, filetype="pdf")
    pages: List[PageInfo] = []
    ocr_budget = 12
    for i, page in enumerate(doc):
        text = page.get_text("text") or ""
        used_ocr = False
        if len(text.strip()) < 40 and ocr_budget > 0:
            ocr = ocr_page(page)
            if len(ocr.strip()) > len(text.strip()):
                text = ocr
                used_ocr = True
            ocr_budget -= 1
        pages.append(PageInfo(name, i + 1, text, classify_page(text), used_ocr))
    return pages


def ranges_by_kind(pages: List[PageInfo]) -> List[Dict[str, Any]]:
    if not pages:
        return []
    out = []
    start = pages[0].page
    last = pages[0].page
    kind = pages[0].kind
    file = pages[0].file
    for p in pages[1:]:
        if p.file == file and p.kind == kind and p.page == last + 1:
            last = p.page
            continue
        out.append({"file": file, "kind": kind, "start": start, "end": last})
        file, kind, start, last = p.file, p.kind, p.page, p.page
    out.append({"file": file, "kind": kind, "start": start, "end": last})
    return [x for x in out if x["kind"] != "outro"]


def find_hits(pages: List[PageInfo], terms: List[str], limit: int = 8) -> List[PageInfo]:
    nts = [norm(x) for x in terms]
    hits = []
    for p in pages:
        t = norm(p.text)
        if any(x in t for x in nts):
            hits.append(p)
            if len(hits) >= limit:
                break
    return hits


def quote(p: PageInfo, needle_terms: List[str], maxlen=260) -> str:
    raw = re.sub(r"\s+", " ", p.text).strip()
    nr = norm(raw)
    pos = -1
    for term in needle_terms:
        pos = nr.find(norm(term))
        if pos >= 0:
            break
    if pos < 0:
        return raw[:maxlen] + ("…" if len(raw) > maxlen else "")
    a = max(0, pos - 80)
    b = min(len(raw), pos + maxlen)
    return ("…" if a else "") + raw[a:b] + ("…" if b < len(raw) else "")


def explicit_no_delivery(pages: List[PageInfo]) -> List[PageInfo]:
    pats = [
        "nenhuma entrega", "nao houve entrega", "não houve entrega", "nao realizou nenhuma entrega",
        "não realizou nenhuma entrega", "sem qualquer entrega", "nada foi entregue", "inexecucao total",
        "inexecução total"
    ]
    return find_hits(pages, pats)


def stage_assessment(pages: List[PageInfo]) -> Dict[str, Any]:
    terms = [
        "abertura de processo administrativo sancionador", "instauracao de processo administrativo sancionador",
        "instauração de processo administrativo sancionador", "instaurar processo administrativo sancionador",
        "apurar responsabilidades", "aplicacao de penalidade", "aplicação de penalidade"
    ]
    hits = find_hits(pages, terms)
    if hits:
        return {
            "stage": "Há decisão/ato que remete a apuração sancionadora posterior.",
            "note": "Os autos analisados podem documentar a inexecução e a decisão contratual, mas a aplicação de sanção deve ser verificada no procedimento sancionador próprio.",
            "refs": [{"file": p.file, "page": p.page} for p in hits[:3]],
        }
    return {"stage": "Estágio sancionador não determinado com segurança.", "note": "Revise os atos finais e a eventual instauração de processo sancionador específico.", "refs": []}


def safe_quantity(pages: List[PageInfo]) -> Dict[str, Any] | None:
    # Só aceita formulações explicitamente ligadas ao total contratado/quantidade total.
    patterns = [
        r"quantidade\s+(?:total\s+)?(?:contratada|prevista|do\s+contrato)\s*[:\-]?\s*(\d{1,6})",
        r"total\s+contratado\s*[:\-]?\s*(\d{1,6})\s+(?:unidades|itens|extintores)",
    ]
    for p in pages:
        t = norm(p.text)
        for pat in patterns:
            m = re.search(pat, t)
            if m:
                val = int(m.group(1))
                ctx = t[max(0, m.start()-100):m.end()+100]
                if any(x in ctx for x in ["por viagem", "por entrega", "metade", "lote parcial"]):
                    continue
                return {"value": val, "file": p.file, "page": p.page}
    return None


def pii_count(text: str) -> int:
    pats = [
        r"\b\d{3}\.\d{3}\.\d{3}-\d{2}\b",
        r"\b\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}\b",
        r"[\w.+'-]+@[\w.-]+\.[A-Za-z]{2,}",
        r"\(?\d{2}\)?\s*9?\d{4}[-\s]?\d{4}",
    ]
    return sum(len(re.findall(p, text, flags=re.I)) for p in pats)


def analyze(pages: List[PageInfo]) -> Dict[str, Any]:
    kinds: Dict[str, List[PageInfo]] = {}
    for p in pages:
        kinds.setdefault(p.kind, []).append(p)

    no_delivery = explicit_no_delivery(pages)
    has_receipt = bool(kinds.get("termo de recebimento"))
    has_defense = bool(kinds.get("defesa")) or bool(find_hits(pages, ["defesa administrativa", "apresentou defesa", "manifestacao da contratada"]))
    has_notice = bool(kinds.get("notificação")) or bool(kinds.get("intimação")) or bool(find_hits(pages, ["notificacao extrajudicial", "fica notificada", "fica intimada"]))
    has_contract = bool(kinds.get("contrato"))
    has_decision = bool(kinds.get("decisão"))

    pendencias = []
    if not has_contract:
        pendencias.append("Não foi localizado contrato/instrumento equivalente.")
    if not has_notice:
        pendencias.append("Não foi localizada notificação/intimação prévia.")
    if not has_defense:
        pendencias.append("Não foi localizada defesa/manifestação da contratada.")
    if not has_receipt and not no_delivery:
        pendencias.append("Não foi localizado termo de recebimento e os autos não registram de forma explícita ausência total de entrega.")

    favorable = []
    if has_defense:
        p = kinds.get("defesa", find_hits(pages, ["defesa administrativa"]))[0]
        favorable.append({"text": "Há defesa/manifestação da contratada nos autos; seus argumentos devem ser confrontados individualmente.", "file": p.file, "page": p.page})

    contrary = []
    if no_delivery:
        p = no_delivery[0]
        contrary.append({"text": "Há registro textual de ausência de entrega/inexecução total.", "file": p.file, "page": p.page, "excerpt": quote(p, ["nenhuma entrega", "nao houve entrega", "inexecucao total"])})

    qty = safe_quantity(pages)
    stage = stage_assessment(pages)

    return {
        "summary": "Análise documental por peças processuais concluída. Revise as referências antes de decidir.",
        "pieces": ranges_by_kind(pages),
        "presence": {
            "contrato": has_contract,
            "notificacao_ou_intimacao": has_notice,
            "defesa": has_defense,
            "decisao": has_decision,
            "termo_recebimento": has_receipt,
            "ausencia_entrega_explicita": bool(no_delivery),
        },
        "pending": pendencias,
        "favorable": favorable,
        "contrary": contrary,
        "quantity": qty,
        "stage": stage,
        "ocr_pages": sum(1 for p in pages if p.ocr),
        "pii": pii_count("\n".join(p.text for p in pages)),
    }


def tokenize(q: str) -> List[str]:
    stop = {"qual","quais","como","onde","houve","existe","tem","foi","foram","uma","um","de","da","do","das","dos","a","o","as","os","e","em","para","por","processo"}
    return [x for x in re.findall(r"[a-z0-9]+", norm(q)) if len(x) > 2 and x not in stop]


def answer_question(proc: Dict[str, Any], q: str) -> Dict[str, Any]:
    pages: List[PageInfo] = proc["pages"]
    nq = norm(q)
    a = proc["analysis"]
    specialized = None

    if "defesa" in nq:
        specialized = "Sim." if a["presence"]["defesa"] else "Não localizei defesa/manifestação com segurança."
    elif "notific" in nq or "intim" in nq:
        specialized = "Sim." if a["presence"]["notificacao_ou_intimacao"] else "Não localizei notificação/intimação com segurança."
    elif "termo de receb" in nq:
        if a["presence"]["termo_recebimento"]:
            specialized = "Sim, foi localizado termo de recebimento."
        elif a["presence"]["ausencia_entrega_explicita"]:
            specialized = "Não localizei termo de recebimento, mas os autos registram ausência de entrega; por isso a falta do termo não é tratada automaticamente como falha documental."
        else:
            specialized = "Não localizei termo de recebimento; essa ausência precisa ser contextualizada antes de qualquer conclusão."
    elif "quantidade" in nq:
        if a["quantity"]:
            specialized = f"Encontrei quantidade total explicitamente indicada: {a['quantity']['value']}."
        else:
            specialized = "Não encontrei uma quantidade total contratada suficientemente explícita para responder com segurança; números ambíguos (por viagem, entrega parcial, metade etc.) foram desconsiderados."
    elif "sanc" in nq or "penal" in nq:
        specialized = a["stage"]["stage"] + " " + a["stage"]["note"]
    elif "entrega" in nq and a["presence"]["ausencia_entrega_explicita"]:
        specialized = "Há registro textual de ausência de entrega/inexecução total nos autos."

    tokens = tokenize(q)
    scored = []
    for p in pages:
        t = norm(p.text)
        score = sum(t.count(tok) for tok in tokens)
        if specialized and any(k in nq for k in ["defesa","notific","intim","decis","parecer"]):
            if p.kind in nq or ("defesa" in nq and p.kind == "defesa") or (("notific" in nq or "intim" in nq) and p.kind in {"notificação","intimação"}):
                score += 5
        if score:
            scored.append((score, p))
    scored.sort(key=lambda x: x[0], reverse=True)
    refs = []
    for _, p in scored[:4]:
        refs.append({"file": p.file, "page": p.page, "kind": p.kind, "excerpt": quote(p, tokens or [q])})

    if specialized:
        ans = specialized
    elif refs:
        ans = "Localizei trechos relacionados à pergunta. Como o modo atual é local e auditável, apresento as fontes prioritárias para conferência humana."
    else:
        ans = "Não encontrei evidência suficiente para responder com segurança. Reformule a pergunta ou verifique se a peça correspondente está nos autos."
    return {"answer": ans, "refs": refs, "classification": "fato documentado" if refs else "pendência"}


@app.get("/api/health")
def health():
    return {"ok": True, "version": "2.0", "mode": "local", "ocr": True}


@app.post("/api/analyze")
async def api_analyze(files: List[UploadFile] = File(...)):
    pages: List[PageInfo] = []
    for f in files:
        data = await f.read()
        if not data:
            continue
        try:
            pages.extend(extract_pages(f.filename or "processo.pdf", data))
        except Exception as e:
            raise HTTPException(400, f"Não foi possível ler {f.filename}: {e}")
    if not pages:
        raise HTTPException(400, "Nenhuma página foi lida.")
    analysis = analyze(pages)
    pid = uuid.uuid4().hex
    PROCESSES[pid] = {"pages": pages, "analysis": analysis, "created": datetime.utcnow().isoformat()}
    return {"process_id": pid, "analysis": analysis, "documents": sorted(set(p.file for p in pages)), "pages": len(pages)}


@app.post("/api/ask")
def api_ask(process_id: str = Form(...), question: str = Form(...)):
    proc = PROCESSES.get(process_id)
    if not proc:
        raise HTTPException(404, "Processo não encontrado nesta sessão.")
    return answer_question(proc, question)


@app.get("/api/report/{process_id}")
def report(process_id: str):
    proc = PROCESSES.get(process_id)
    if not proc:
        raise HTTPException(404, "Processo não encontrado nesta sessão.")
    a = proc["analysis"]
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
    styles = getSampleStyleSheet()
    story = [Paragraph("Fiscaliza.AI Municipal — Relatório de análise documental", styles["Title"]), Spacer(1, 12)]
    story.append(Paragraph(a["summary"], styles["BodyText"]))
    story.append(Spacer(1, 10))
    story.append(Paragraph("Peças processuais localizadas", styles["Heading2"]))
    rows = [["Tipo", "Arquivo", "Páginas"]]
    for x in a["pieces"]:
        pg = str(x["start"]) if x["start"] == x["end"] else f"{x['start']}–{x['end']}"
        rows.append([x["kind"], x["file"][:55], pg])
    if len(rows) == 1:
        rows.append(["—", "Nenhuma classificação segura", "—"])
    t = Table(rows, colWidths=[100, 330, 60])
    t.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.4,colors.grey),("BACKGROUND",(0,0),(-1,0),colors.lightgrey),("VALIGN",(0,0),(-1,-1),"TOP")]))
    story += [t, Spacer(1, 12), Paragraph("Pendências", styles["Heading2"])]
    for x in a["pending"] or ["Nenhuma pendência automática identificada."]:
        story.append(Paragraph("• " + x, styles["BodyText"]))
    story += [Spacer(1, 10), Paragraph("Estágio sancionador", styles["Heading2"]), Paragraph(a["stage"]["stage"] + " " + a["stage"]["note"], styles["BodyText"]) ]
    story += [Spacer(1, 12), Paragraph("Observação", styles["Heading2"]), Paragraph("A ferramenta organiza evidências e não substitui a decisão humana. Confira as peças originais antes de qualquer providência.", styles["BodyText"])]
    doc.build(story)
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/pdf", headers={"Content-Disposition":"attachment; filename=fiscaliza_relatorio.pdf"})


HTML = r'''<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fiscaliza.AI Municipal</title>
<style>
:root{--navy:#0b3a49;--blue:#2559e8;--green:#078a61;--bg:#f4f7fb;--line:#dce4ee;--text:#091b30;--muted:#5f7087}*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,Segoe UI,Arial;color:var(--text);background:var(--bg)}.shell{display:grid;grid-template-columns:270px 1fr;min-height:100vh}.side{background:var(--navy);color:white;padding:22px 18px;position:sticky;top:0;height:100vh}.side h2{margin:0;font-size:22px}.side small{display:block;margin-top:4px}.badge{margin-top:28px;border:1px solid #426472;border-radius:14px;padding:14px;font-size:13px;line-height:1.5}.main{padding:28px}.top{display:flex;justify-content:space-between;gap:20px;align-items:flex-start}.top h1{font-size:34px;max-width:1100px;margin:8px 0}.eyebrow{font-size:12px;font-weight:800;letter-spacing:.1em;color:#60758e}.lead{color:var(--muted);max-width:1100px}.status{white-space:nowrap;background:#e9f1ff;color:#1f56d7;border-radius:20px;padding:8px 12px;font-size:12px;font-weight:700}.card{background:#fff;border:1px solid var(--line);border-radius:18px;padding:20px;margin-top:18px;box-shadow:0 10px 25px rgba(16,40,70,.04)}.drop{border:2px dashed #8fb0df;text-align:center;padding:30px;border-radius:16px}.btn{background:var(--blue);border:0;color:white;font-weight:800;border-radius:12px;padding:12px 18px;cursor:pointer}.btn.green{background:var(--green)}input[type=file]{margin:12px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.piece{padding:10px;border:1px solid var(--line);border-radius:12px;margin:8px 0}.ok{border-left:4px solid var(--green)}.warn{border-left:4px solid #c98200}.muted{color:var(--muted)}#results{display:none}.qbox{display:flex;gap:8px}.qbox input{flex:1;padding:12px;border:1px solid var(--line);border-radius:10px}.ref{font-size:13px;background:#f7f9fc;border:1px solid var(--line);padding:10px;border-radius:10px;margin-top:8px}.chips{display:flex;flex-wrap:wrap;gap:7px}.chip{font-size:12px;background:#eef3f8;border-radius:15px;padding:6px 9px}@media(max-width:850px){.shell{grid-template-columns:1fr}.side{height:auto;position:static}.grid{grid-template-columns:1fr}.top{display:block}.main{padding:18px}}
</style></head><body><div class="shell"><aside class="side"><h2>Fiscaliza.AI Municipal</h2><small>Copiloto auditável para pequenos municípios</small><div class="badge"><b>IA responsável por design</b><br>OCR em português, respostas fundamentadas e decisão humana obrigatória.</div></aside><main class="main"><div class="top"><div><div class="eyebrow">FISCALIZA.AI MUNICIPAL</div><h1>Entenda um processo administrativo em minutos — com cada resposta ligada à prova.</h1><div class="lead">Agora com leitura por peças processuais dentro do mesmo PDF: contrato, notificação, defesa, pareceres, decisão e outras peças são analisados separadamente.</div></div><div class="status">OCR ativo · IA: modo local</div></div>
<div class="card"><div class="drop"><h3>Envie PDFs do processo</h3><input id="files" type="file" accept="application/pdf" multiple><br><button class="btn" onclick="analyze()">Analisar documentos</button><div id="loading" class="muted" style="margin-top:10px"></div></div></div>
<div id="results"><div class="card"><div class="grid"><div><h2>Peças processuais localizadas</h2><div id="pieces"></div></div><div><h2>Leitura assistida</h2><div id="presence"></div><h3>Pendências contextuais</h3><div id="pending"></div></div></div></div>
<div class="card"><h2>Pergunte ao processo</h2><div class="qbox"><input id="q" placeholder="Ex.: Há defesa? Qual o estágio sancionador? Houve entrega?"><button class="btn" onclick="ask()">Perguntar</button></div><div id="answer" style="margin-top:14px"></div></div>
<div class="card"><div class="grid"><div><h2>Estágio sancionador</h2><div id="stage"></div></div><div><h2>Privacidade e OCR</h2><div id="privacy"></div></div></div><div style="margin-top:16px"><button class="btn green" onclick="report()">Baixar relatório PDF</button></div></div></div>
</main></div><script>
let pid=null;function esc(s){return String(s??'').replace(/[&<>\"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]))}
async function analyze(){const fs=document.getElementById('files').files;if(!fs.length){alert('Escolha ao menos um PDF.');return}const fd=new FormData();[...fs].forEach(f=>fd.append('files',f));loading.textContent='Analisando páginas e peças processuais…';try{const r=await fetch('/api/analyze',{method:'POST',body:fd});const j=await r.json();if(!r.ok)throw new Error(j.detail||'Falha na análise');pid=j.process_id;render(j);results.style.display='block';setTimeout(()=>results.scrollIntoView({behavior:'smooth'}),100)}catch(e){alert(e.message)}finally{loading.textContent=''}}
function render(j){const a=j.analysis;pieces.innerHTML=a.pieces.length?a.pieces.map(x=>`<div class="piece ok"><b>${esc(x.kind)}</b><br><span class="muted">${esc(x.file)} · p. ${x.start}${x.end!==x.start?'–'+x.end:''}</span></div>`).join(''):'<div class="muted">Nenhuma peça classificada com segurança.</div>';const p=a.presence;presence.innerHTML=`<div class="chips"><span class="chip">Contrato: ${p.contrato?'sim':'não'}</span><span class="chip">Notificação/intimação: ${p.notificacao_ou_intimacao?'sim':'não'}</span><span class="chip">Defesa: ${p.defesa?'sim':'não'}</span><span class="chip">Decisão: ${p.decisao?'sim':'não'}</span><span class="chip">Ausência de entrega explícita: ${p.ausencia_entrega_explicita?'sim':'não'}</span></div>`+(a.quantity?`<p><b>Quantidade total explicitamente localizada:</b> ${a.quantity.value} — p. ${a.quantity.page}</p>`:`<p class="muted">Quantidade total: não afirmada quando a referência é ambígua.</p>`);pending.innerHTML=a.pending.length?a.pending.map(x=>`<div class="piece warn">${esc(x)}</div>`).join(''):'<div class="piece ok">Nenhuma pendência automática identificada.</div>';stage.innerHTML=`<p><b>${esc(a.stage.stage)}</b></p><p>${esc(a.stage.note)}</p>`;privacy.innerHTML=`<p><b>Dados pessoais detectados:</b> ${a.pii}<br><b>Páginas processadas por OCR:</b> ${a.ocr_pages}<br><b>Total de páginas:</b> ${j.pages}</p><p class="muted">Revise e redija dados pessoais antes de compartilhar com serviços externos.</p>`}
async function ask(){if(!pid){alert('Analise um processo primeiro.');return}const fd=new FormData();fd.append('process_id',pid);fd.append('question',q.value);answer.innerHTML='Consultando…';const r=await fetch('/api/ask',{method:'POST',body:fd});const j=await r.json();answer.innerHTML=`<p><b>${esc(j.answer)}</b></p>`+(j.refs||[]).map(x=>`<div class="ref"><b>${esc(x.kind)} · ${esc(x.file)} · p. ${x.page}</b><br>${esc(x.excerpt)}</div>`).join('')}
function report(){if(!pid){alert('Analise um processo primeiro.');return}location.href='/api/report/'+pid}
</script></body></html>'''

@app.get("/", response_class=HTMLResponse)
def home():
    return HTML
